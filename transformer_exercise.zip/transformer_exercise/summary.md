Student 1:
* Name: 
* ID:
* Username:

Student 2:
* Name: 
* ID:
* Username:

Student 3:
* Name: 
* ID:
* Username:

Now, for each log file that you need to submit, you will need to write its last 3 lines. For example, this is what we got for `baseline_gen.log`:
```txt
2021-04-24 17:20:46 | INFO | fairseq_cli.generate | NOTE: hypothesis and token scores are output in base 2
2021-04-24 17:20:46 | INFO | fairseq_cli.generate | Translated 7,283 sentences (165,025 tokens) in 18.5s (394.00 sentences/s, 8927.61 tokens/s)
Generate valid with beam=5: BLEU4 = 33.39, 69.1/42.8/28.5/19.4 (BP=0.934, ratio=0.937, syslen=138824, reflen=148229)
```

3 last lines from the baseline_train.log file: 
```txt
<write here>
```

3 last lines from the baseline_gen.log file: 
```txt
<write here>
```

3 last lines from the baseline_mask.log file: 
```txt
<write here>
```

25 last lines from the check_all_masking_options.log file: 
```txt
<write here>
```

3 last lines from the sandwich_train.log file: 
```txt
<write here>
```

3 last lines from the sandwich_gen.log file: 
```txt
<write here>
```